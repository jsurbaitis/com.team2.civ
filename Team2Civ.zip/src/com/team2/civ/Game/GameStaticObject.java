package com.team2.civ.Game;

import java.awt.image.BufferedImage;

import com.team2.civ.Map.WalkableTile;

public class GameStaticObject extends WalkableTile {

	public GameStaticObject(int mapX, int mapY, BufferedImage bitmap) {
		super(mapX, mapY, bitmap);
		
	}
}
