package com.team2.civ.Game;

import java.awt.image.BufferedImage;

import com.team2.civ.Map.MovingMapObject;

public class GameUnit extends MovingMapObject {

	public GameUnit(int mapX, int mapY, BufferedImage bitmap) {
		super(mapX, mapY, bitmap);

	} 

}
