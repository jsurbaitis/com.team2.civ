package com.team2.civ.Data;

public class GameStaticObjectData {

}
