package com.team2.civ.Data;

import java.awt.image.BufferedImage;

public class AnimData {
	public BufferedImage frames[];
	public int length;
	public int loopCount;

}
