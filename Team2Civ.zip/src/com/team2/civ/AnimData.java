package com.team2.civ;

public class AnimData {

}
